TMControlPanel — Chicane v1

All assets are based on the approved Chicane v1 design.
SVG artwork and lettering use vector paths; no fonts or embedded bitmap images.

Quick choices:
- logo-stacked.svg / .png: approved stacked composition, light backgrounds
- logo-horizontal.svg / .png: wide composition, light backgrounds
- *-dark: green symbol and white lettering for dark backgrounds
- *-black and *-white: monochrome versions
- mark.svg / .png: symbol only, tight crop
- ui-mark.svg: transparent square symbol for interfaces
- icon.svg and icon-*.png: symbol on a charcoal tile
- icon-maskable.svg / icon-maskable-512.png: mask-safe app icon
- apple-touch-icon.png: 180px iOS icon
- favicon.ico: 16, 32, 48, 64 and 256px frames
- social.svg / .png: 1200x630 social card
- masters/: editable traced vector source artwork

Transparent logos reveal the background through the chicane and indicator holes.
Colors: green #22c55e; charcoal #18181b; off-white #fafafa.
The white and dark variants are intended for dark backgrounds.

Repository guide: docs/branding/README.md
Rebuild command (inside the repository with dependencies installed):
  node apps/web/scripts/generate-branding.mjs
